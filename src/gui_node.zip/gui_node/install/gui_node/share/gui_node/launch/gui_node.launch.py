from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='gui_node',
            executable='gui_node_exec',
            name='gui_node'
        )
        ExecuteProcess(
            cmd=['rviz2', '-d', '/path/to/my_jenga_config.rviz'],
            output='screen'
        )
    ])
